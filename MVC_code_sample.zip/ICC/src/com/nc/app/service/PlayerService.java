package com.nc.app.service;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.nc.app.dao.IPlayerDAO;
import com.nc.app.dao.PlayerDAO;
import com.nc.app.dto.Player;
import com.nc.app.util.CricketException;

public class PlayerService {
	
	IPlayerDAO dao = new PlayerDAO();
	
	public List<Player> getAllPlayers() throws CricketException
	{
		
		System.out.println("---------------\n\n\n----------------------\n\n\n------IN get all players in playerservice");
		return dao.getAllPlayers();
	}
	
	public boolean addNewPlayer(Player player) throws CricketException, SQLException
	{
		return dao.addNewPlayer(player);
		
	}
	
	public List<String> getAllCountries()
	{
		List<String> countries = new ArrayList<>();
		
		countries.add("India");
		countries.add("England");
		countries.add("Australia");
		countries.add("Sri Lanka");
		countries.add("New Zealand");
		
		return countries;
				
	}

	
	
	
}
