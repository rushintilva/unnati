package com.nc.app.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.nc.app.dto.Player;
import com.nc.app.util.CricketException;
import com.nc.app.util.DBUtil;

public class PlayerDAO implements IPlayerDAO {
	
	@Override
	public List<Player> getAllPlayers() throws CricketException
	{
		List<Player> players= new ArrayList<Player>();
		String query = "select * from cricket_score";
		
		System.out.println("in dao.getAllPlayers, before try");
		
		try(Connection connection = DBUtil.getConnection())
		{
			System.out.println("within try now : connection");
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery(query);
			
			
			System.out.println("IN PLAYERDAO : size of resultset  : "+rs.getFetchSize());
			
			while(rs.next())
			{
				Player currentRowPlayer = new Player();
				
				currentRowPlayer.setPlayerId(rs.getInt("player_id"));
				currentRowPlayer.setPlayerName(rs.getString("player_name"));
				currentRowPlayer.setCountry(rs.getString("country"));
				currentRowPlayer.setBattingStyle(rs.getString("batting_style"));
				currentRowPlayer.setCenturies(rs.getInt("centuries"));
				currentRowPlayer.setMatches(rs.getInt("matches"));
				currentRowPlayer.setTotalRunScore(rs.getInt("total_run_score"));
				currentRowPlayer.setDateOfBirth(rs.getDate("dob").toLocalDate());
				
				System.out.println("Added player : "+currentRowPlayer.getPlayerName());
			
				players.add(currentRowPlayer);
			}
			
		} catch (SQLException e) {
			throw new CricketException("Problem in loading list : "+e.getMessage());
		
		}
		
		catch(CricketException e)
		{
			throw new CricketException("Problem in loading list : "+e.getMessage());
			
		}		
		
		
		
		return players;
	}

	@Override
	public boolean addNewPlayer(Player player) throws SQLException, CricketException {
String query = "insert into cricket_score(player_name, country, batting_style, centuries, matches, total_run_score, dob) values(?,?,?,?,?,?,?)";
		
		
		try(Connection connection = DBUtil.getConnection())
		{
			
			PreparedStatement ps = connection.prepareStatement(query);
			
			ps.setString(1, player.getPlayerName());
			ps.setString(2, player.getCountry());
			ps.setString(3, player.getBattingStyle());

			ps.setInt(4, player.getCenturies());
			ps.setInt(5, player.getMatches());
			ps.setInt(6, player.getTotalRunScore());
			
			ps.setDate(7, Date.valueOf(player.getDateOfBirth()));
			
			
			if(ps.executeUpdate() > 0) return true;
			
			
			
			
		}
		catch(SQLException e)
		{
			throw new CricketException("Problem in adding player : "+e.getMessage());
			
		}
		
		catch(CricketException e)
		{
			throw new CricketException("Problem in adding player : "+e.getMessage());
		}
		
		
		return false;
	}
	
	

}
