package com.nc.app.dao;

import java.sql.SQLException;
import java.util.List;

import com.nc.app.dto.Player;
import com.nc.app.util.CricketException;

public interface IPlayerDAO {
	
	List<Player> getAllPlayers() throws CricketException;
	
	boolean addNewPlayer(Player player) throws SQLException, CricketException;
	

}
