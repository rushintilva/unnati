package com.nc.app.dto;

import java.time.LocalDate;

public class Player {
	
	private int playerId, centuries, matches, totalRunScore;
	private LocalDate dateOfBirth;
	private String playerName, country, battingStyle;
	
	
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public int getCenturies() {
		return centuries;
	}
	public void setCenturies(int centuries) {
		this.centuries = centuries;
	}
	public int getMatches() {
		return matches;
	}
	public void setMatches(int matches) {
		this.matches = matches;
	}
	public int getTotalRunScore() {
		return totalRunScore;
	}
	public void setTotalRunScore(int totalRunScore) {
		this.totalRunScore = totalRunScore;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate localDate) {
		this.dateOfBirth = localDate;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getBattingStyle() {
		return battingStyle;
	}
	public void setBattingStyle(String battingStyle) {
		this.battingStyle = battingStyle;
	}
	
	

}