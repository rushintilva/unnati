package com.nc.app.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nc.app.dto.Player;
import com.nc.app.service.PlayerService;
import com.nc.app.util.CricketException;

/**
 * Servlet implementation class FrontController
 */


@WebServlet(name = "FrontControllerServlet", urlPatterns={"*.html"})
public class FrontControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private PlayerService service;
	
	
	public FrontControllerServlet() {
		System.out.println("---------------------------------IN FRONt CONtroller constr");
    }
	
	@Override
	public void init()
	{
		service = new PlayerService();
		
		System.out.println("---------------------------------IN FRONt CONtroller INIT");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().println("path  :  "+request.getRequestURL().toString());
		
		String target = "/WEB-INF/index.jsp";
		String requestPage = request.getRequestURI().toString();
		
		if(requestPage.endsWith("index.html"))
		{
			target = "/WEB-INF/index.jsp";
		}
		
		else if(requestPage.endsWith("viewPlayers.html"))
		{
			try
			{
			
			//System.out.println("\n\n\nIN FRONT CONTROLLER : PLAYERS size : "+service.getAllPlayers().size()+"\n\n\n");
			
			
		
			
				request.setAttribute("plist", service.getAllPlayers());
				//System.out.println("\n\n\nIN FRONT CONTROLLER : PLAYERS size : "+service.getAllPlayers().size()+"\n\n\n");
				
				
				/*for(Player player : service.getAllPlayers())
				{
				System.out.println(player.getPlayerName());
				}*/
				
				
			}
			catch(CricketException e)
			{
				target = "/WEB-INF/error.jsp";
			}
			catch(Exception e)
			{
			target = "/WEB-INF/error.jsp";
			System.out.println("target : "+target);


			
			}
			
			target=  "/WEB-INF/viewPlayers.jsp";
		}
		else if(requestPage.endsWith("addPlayer.html"))
		{
			
			request.setAttribute("countries", service.getAllCountries());
		
			target = "/WEB-INF/addPlayer.jsp";
		}
		
		System.out.println("target : "+target);
		RequestDispatcher dispatch = request.getRequestDispatcher(target);
		
		dispatch.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}