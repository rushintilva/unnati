package com.nc.app.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil {
	
	private static Connection connection;
	
	private DBUtil() {}
	public static Connection getConnection() throws CricketException
	{
		System.out.println("IN dbutil.getConn : connection : "+connection);
		
		try
		{
			System.out.println("in try block in getconn");
			
			
			if(connection == null || connection.isClosed())
			{
				System.out.println("inside if condition");
				InitialContext context = new InitialContext();
				System.out.println("context created");
				
				
				DataSource ds = (DataSource)context.lookup("java:/comp/env/jdbc/mydb");
				System.out.println("Data source created : ds : "+ds);
				
				
				connection = ds.getConnection();
				
				System.out.println("----------------\n\n\n-------------- CONNECTION BAN GAYA!");
				
				
			}
			
		}
		catch(SQLException e)
		{
			throw new CricketException("Problem in getting connection : "+e.getMessage());
			
		}
		catch (NamingException e) {
			throw new CricketException("Problem in getting connection : "+e.getMessage());
			
		}
		catch(Exception e)
		{
			System.out.println("here in exception : connection : "+connection);
		}
		
		System.out.println("connection : "+connection);
		
		return connection;
	}
	

}
